import * as React from 'react';
import { View, Text, Button, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

function BemVindo({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>SEJA BEM VIND@ AO MAPA DO T.I!</Text>
      <View>
        <TouchableOpacity style={{
          margin: 12,
          height: 50,
          width: 120,
          borderRadius: 30,
          backgroundColor: 'blue', // Changed from 'background' to 'backgroundColor'
          justifyContent: 'center',
          alignItems: 'center',
          borderWidth: 0, // Changed from 'border' to 'borderWidth'
          fontSize: 16,
        }}
          onPress={() => navigation.navigate('Home')}>
          <Text style={{ color: 'white' }}>Faça login</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function Home({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Ola Usuario</Text>
      <TouchableOpacity style={{
          margin: 12,
          height: 50,
          width: 120,
          borderRadius: 30,
          backgroundColor: 'blue', // Changed from 'background' to 'backgroundColor'
          justifyContent: 'center',
          alignItems: 'center',
          borderWidth: 0, // Changed from 'border' to 'borderWidth'
          fontSize: 16,
        }}
          onPress={() => navigation.navigate('Home')}>
          <Text style={{ color: 'white' }}>Faça login</Text>
        </TouchableOpacity>
    </View>
  );
}

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="BemVindo" component={BemVindo} />
        <Stack.Screen name="Home" component={Home} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
